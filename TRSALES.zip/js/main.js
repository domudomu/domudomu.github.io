// $(function () {
//   $('[data-toggle="popover"]').popover()
// })
$(document).ready(function () {
  $('#navbar-toggler-icon-animated').click(function () {
      $(this).toggleClass('open')
  })
});